# from PlayersandMonsters.project.hero import Hero
from project.hero import Hero



class Elf(Hero):
    pass

    # def __repr__(self, username, level):
    #     Hero.__init__(self, username, level)
    #
    # def __repr__(self):
    #     string = Hero.__repr__(self)
    #     # return  f"{self.username} of type {self.__class__.__name__} has level {self.level}"
    #     return string


