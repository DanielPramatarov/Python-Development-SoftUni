# from PlayersandMonsters.project.elf import Elf
from project.elf import Elf


class MuseElf(Elf):
    pass

    # def __init__(self, username, level):
    #     Elf.__init__(self,username, level)
    #
    #
    # # def __repr__(self):
    # #     string = Elf.__repr__(self)
    # #     # return  f"{self.username} of type {self.__class__.__name__} has level {self.level}"
    # #     return string
    # #
