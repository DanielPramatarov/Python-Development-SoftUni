# from PlayersandMonsters.project.knight import Knight
from project.knight import Knight


class DarkKnight(Knight):
    pass

    # def __init__(self, username, level):
    #     Knight.__init__(self, username, level)
    #
    #
    # def __repr__(self):
    #     string = Knight.__repr__(self)
    #     # return  f"{self.username} of type {self.__class__.__name__} has level {self.level}"
    #     return string
    #
