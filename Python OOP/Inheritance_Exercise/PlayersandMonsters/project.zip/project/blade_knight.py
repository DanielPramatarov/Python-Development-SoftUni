# from PlayersandMonsters.project.dark_knight import DarkKnight
from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass

    # def __init__(self,username, level):
    #     DarkKnight.__init__(self,username,level)
    #
    # def __repr__(self):
    #     string = DarkKnight.__repr__(self)
    #     # return  f"{self.username} of type {self.__class__.__name__} has level {self.level}"
    #     return string
